/*
CH-230-A
a12_p7.[cpp]
Georgi Shopov
gshopov@jacobs-university.de
*/

#ifndef _CIRCLE_H
#define _CIRCLE_H
#include "Area.h"

class Circle : public Area {
	public:
		Circle(const char *n, double a);
		~Circle();
		double calcArea() const;
		double calcPer() const;
		//getter for radius to use it in the Ring class
		double getRadius() const
		{
			return this->radius;
		}
	private:
		double radius;
};

#endif
