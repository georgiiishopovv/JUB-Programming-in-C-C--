/*
CH-230-A
a12_p7.[cpp]
Georgi Shopov
gshopov@jacobs-university.de
*/

#ifndef _AREA_H
#define _AREA_H

class Area {
	public:
		Area(const char *n);
		virtual ~Area();
		void getColor() const;
		virtual double calcArea() const = 0;
		//create a virtual parameter for calculating the parameters
		//of the different shapes
		virtual double calcPer() const = 0;
	private:
		char color[11];
};
#endif
