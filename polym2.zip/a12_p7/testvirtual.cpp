/*
CH-230-A
a12_p7.[cpp]
Georgi Shopov
gshopov@jacobs-university.de
*/

#include <iostream>
using namespace std;
#include "Area.h"
#include "Circle.h"
#include "Ring.h"
#include "Rectangle.h"
#include "Square.h"

/*
	Area
	/  \
   /    \
Circle Rectangle
  |		  |
  |		  |
 Ring   Square

*/
 
const int num_obj = 25;
int main() {
	Area* list[num_obj];
	const char* colors_arr[4] = {"RED", "BLACK", "VIOLET", "BLUE"};		
	//store the sums of the areas and parameters 											
	double sum_area = 0.0;
	double sum_per = 0.0;
	
	//initialize random number generator
	srand(static_cast<unsigned int>(time(0)));

	for(int i = 0; i < num_obj; i++)
	{
		int classes = rand() % 4; //4 different classes
		int colors = rand() % 4; //4 different colors
		int sizes1 = rand() % 96 + 5; //sizes from 5 to 100
		int sizes2 = rand() % 96 + 5; //sizes from 5 to 100

		//create a random shape with random parameters
		switch(classes)
		{
			case 0:
				cout << endl;
				//a circle has color and radius
				list[i] = new Circle(colors_arr[colors], sizes1);
				list[i]->getColor();
				sum_area += list[i]->calcArea();
				cout << endl;
				sum_per += list[i]->calcPer();
				cout << endl;
				break;
			case 1:
				cout << endl;
				//a ring has a color, inner and outer radiuses
				list[i] = new Ring(colors_arr[colors], sizes1, sizes2);
				list[i]->getColor();
				sum_area += list[i]->calcArea();
				cout << endl;
				sum_per += list[i]->calcPer();
				cout << endl;
				break;
			case 2:
				cout << endl;
				//a rectangle has a color, height and width
				list[i] = new Rectangle(colors_arr[colors], sizes1, sizes2);
				list[i]->getColor();
				sum_area += list[i]->calcArea();
				cout << endl;
				sum_per += list[i]->calcPer();
				cout << endl;
				break;
			case 3: 
				cout << endl;
				//a square has a color and side
				list[i] = new Square(colors_arr[colors], sizes1);
				list[i]->getColor();
				sum_area += list[i]->calcArea();
				cout << endl;
				sum_per += list[i]->calcPer();
				cout << endl;
				break;
			default:
				break;
		}
	}

	cout << endl;
	cout << "Total area: " << sum_area << endl;
	cout << "Total perimeter " << sum_per << endl;

	//releasing the allocated memory
	for(int i = 0; i < num_obj; i++)
	{
		delete list[i];
	}
}

