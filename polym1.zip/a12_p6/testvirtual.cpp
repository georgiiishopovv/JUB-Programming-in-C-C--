/*
CH-230-A
a12_p6.[cpp]
Georgi Shopov
gshopov@jacobs-university.de
*/

#include <iostream>
using namespace std;
#include "Area.h"
#include "Circle.h"
#include "Ring.h"
#include "Rectangle.h"

/*
	Area
	/  \
   /    \
Circle Rectangle
  |		  |
  |		  |
 Ring   Square

*/
 
const int num_obj = 6;
int main() {
	Area *list[num_obj];						// (1)
	// (1) - we create an array of Area pointer objects - since this is a 
	// parent class, all child objects can also be stored (upcasting)
	int index = 0;								// (2)
	// (2) set a variable that will help us access the objects 
	// in the array
	double sum_area = 0.0;						// (3)
	// (3) - initialize a variable that will store the sum
	cout << "Creating Ring: ";
	Ring blue_ring("BLUE", 5, 2);				// (4)
	// (4) - creating a Ring object
	cout << "Creating Circle: ";
	Circle yellow_circle("YELLOW", 7);
	cout << "Creating Rectangle: ";
	Rectangle green_rectangle("GREEN",5,6);
	cout << "Creating Circle: ";
	Circle red_circle("RED", 8);
	cout << "Creating Rectangle: ";
	Rectangle black_rectangle("BLACK", 10, 20);
	cout << "Creating Ring: ";
	Ring violet_ring("VIOLET", 100, 5);
	list[0] = &blue_ring;						// (5)
	// (5) - we store the address of the blue_ring object, which is instance
	// of the Ring class, in the first element of the pointer array
	list[1] = &yellow_circle;
	list[2] = &green_rectangle;
	list[3] = &red_circle;
	list[4] = &black_rectangle;
	list[5] = &violet_ring;
	while (index < num_obj) {					// (7)
	// (7) - iterate through all of the objects using the index variable
	// and the constant variable, which is equal to 6
		(list[index])->getColor();				
		double area = list[index++]->calcArea(); // (8)
		// (8) - we find the area of a specific object, store it in
		// the area variable, which will then be added to the sum_area
		// in order to compute the sum of the different areas
		sum_area += area;
	}
	cout << "\nThe total area is "
			<< sum_area << " units " << endl;	// (9)
	// (9) - the total area of all objectrs will be printed using 
	// the sum_area variable

	index = 0;
	double sum_perimeter = 0;
	//summing all perimeters
	while(index < num_obj)
	{
		list[index]->getColor();
		sum_perimeter += list[index]->calcPer();
		index++;
	}
	cout << "\nThe total perimeter is " << sum_perimeter << " units" << endl;
	return 0;
}

