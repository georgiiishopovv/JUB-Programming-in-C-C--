/*
CH-230-A
a12_p7.[cpp]
Georgi Shopov
gshopov@jacobs-university.de
*/

#ifndef _RECTANGLE_H
#define _RECTANGLE_H
#include "Area.h"

class Rectangle : public Area {
	public:
		Rectangle(const char *n, double a, double b);
		~Rectangle();
		double calcArea() const;
		double calcPer() const;
	private:
		double length;
		double width;
};

#endif
