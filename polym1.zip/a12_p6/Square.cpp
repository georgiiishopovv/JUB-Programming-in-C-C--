/*
CH-230-A
a12_p7.[cpp]
Georgi Shopov
gshopov@jacobs-university.de
*/

#include <iostream>
#include "Square.h"

//parameterized constructors inheriting from Rectangle
Square::Square(const char *n, double side) : Rectangle(n, side, side)
{
    this->side =  side;
}

Square::~Square()
{

}

//area of square
double Square::calcArea() const
{
    std::cout << "calcArea of Square...";
    return side*side;
}

//perimeter of square
double Square::calcPer() const
{
    std::cout << "calcPerimeter of Square...";
    return 4*side;
}
